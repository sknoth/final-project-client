console.log('CREATE PROFILE FILE');
document.getElementById("createProfileBtn").addEventListener("click", app.onCreateProfile);
